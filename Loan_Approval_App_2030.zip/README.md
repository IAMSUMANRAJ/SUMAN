
# Loan Approval Prediction 2030 🚀

This futuristic app predicts whether a loan will be approved based on user input.
Built using Machine Learning (Random Forest Classifier) and Streamlit.

## Features
- Predicts Loan Status (Approved/Rejected)
- Futuristic UI with animations
- Easy form input

## How to Run

1. Install requirements:
```
pip install -r requirements.txt
```

2. Run the app:
```
streamlit run app.py
```

Enjoy the future of Loan Approvals! 🔮
