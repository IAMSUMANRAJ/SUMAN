
import streamlit as st
import pickle
import numpy as np

# Load the trained model
model = pickle.load(open("loan_model.pkl", "rb"))

st.set_page_config(page_title="Loan Approval Prediction 2030 🚀", layout="centered")
st.title("🏦 Loan Approval Prediction 2030")
st.subheader("Enter your details below and predict your Loan Status")

# Input Fields
Gender = st.selectbox("Gender", ["Male", "Female"])
Married = st.selectbox("Married", ["Yes", "No"])
ApplicantIncome = st.number_input("Applicant Monthly Income ($)", min_value=0)
Credit_History = st.selectbox("Credit History", ["Good (1)", "Bad (0)"])
LoanAmount = st.slider("Loan Amount (in $1000s)", 1, 500, step=1)

# Predict Function
def predict_loan(Gender, Married, ApplicantIncome, Credit_History, LoanAmount):
    gender = 1 if Gender == "Male" else 0
    married = 1 if Married == "Yes" else 0
    credit = 1 if Credit_History == "Good (1)" else 0
    loan_amount = LoanAmount
    applicant_income = ApplicantIncome

    features = np.array([[gender, married, applicant_income, credit, loan_amount]])
    prediction = model.predict(features)
    return prediction[0]

# Predict Button
if st.button("Predict Loan Approval 🚀"):
    result = predict_loan(Gender, Married, ApplicantIncome, Credit_History, LoanAmount)
    if result == 1:
        st.success("✅ Loan Approved!")
        st.balloons()
    else:
        st.error("❌ Loan Rejected!")

st.caption("Developed with ❤️ by Machan for 2030 🔮")
